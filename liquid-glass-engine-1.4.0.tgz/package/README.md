# liquid-glass-engine

**iOS 26 液态玻璃引擎** —— 可复用的 React 液态玻璃渲染引擎。纯 SVG/DOM 实现（无 WebGL 依赖），把一整块"会流动的玻璃"做成了挂载即用的组件。

> 本引擎从 Apple Music 复刻应用（24 轮迭代打磨）中抽取而成，覆盖 G2 连续曲率几何、矢量高光、液桥融合、玻璃分裂/合并转场、弹簧形变、逐玻璃自动模糊/自动变色与 Flash/Pro 双档位。

## 特性

- **G2 连续曲率几何**：胶囊 / squircle（n=3.4 超椭圆）/ 正圆 / roundrect，全部由 SDF 解析生成，放大不失真、严禁 transform 非等比拉伸
- **矢量高光**：SVG 高光弧骑在玻璃边界上（非贴图），左右双弧非对称（暖白主弧 + 冷白辅弧）
- **液桥融合**：邻近同组玻璃接触时 smooth-min "融化"出表面张力颈部，whiteness 积分白化，分离自动断桥；卡片自动排除。**v1.3.0** 配对判定放宽：中心对齐（±10px）或轴向投影重叠 ≥ 较小边 35%（同排横邻/同列竖邻）—— 混高行（如 96px 输入面板 + 48px 圆钮底对齐）亦可配对，静止间距窗口 (12, 24] 不变
- **玻璃分裂/合并**：玻璃从源玻璃"分裂出生"、滑回源玻璃"合并吸收"——材料守恒，玻璃永不离场
- **弹簧形变**：形状族切换（圆⇄胶囊⇄超椭圆）五次 smootherstep C2 混合 + 软弹簧 ≈400ms 液态仿生阻尼；逐帧点阵混合连续轮廓（60fps 无级，无阶跃）
- **自动变色**：三色调（白/中性/黑）+ 全动态透明度 + 迟滞三态机 + 液桥聚簇统一（融合时不变色）
- **自动模糊**：逐玻璃文字密度驱动，硬性界线 [2px, 5px]
- **Flash / Pro 双档位**：Flash 降耗档（采样降频 + 30fps + 静止停帧）、Pro 全速档、auto 按活动性自动升降
- **autoResize 行高自适应**（v1.3.0）：引擎以 ResizeObserver 观察全部玻璃本体，内容驱动的尺寸变化（如输入框多行增长）rAF 合帧即时重同步折射贴图 / clip-path / 阴影 / 高光
- **morph dur 时长**（v1.3.0）：`lgEvents.morph({..., dur})` 可选形变时长 ms（90–1200），时间驱动 liquidSettle 曲线（过冲 2.34%）→ settle 严格 ≈ dur；缺省完整保留 v1.2 弹簧积分（软/硬弹簧家族）
- **液桥组层级自适应**（v1.4.0）：每个液桥组独立宿主层，`z = max(rootStackZ(成员)) + 5` —— 组阴影/液桥颈永远浮在成员所在界面层之上、其它界面之下；修复「宿主层被钉死 → 组阴影被不透明覆盖层吃掉 / 切界面幽灵残留」两类事故。分裂孪生同样 inline 跟随源玻璃界面层（≥480 基线）
- **precache 分片化**（v1.4.0）：`lgEvents.precache()` 关键帧生成改为 rAF 切片（每片 ≤6ms），消除首次形变前数百 ms~秒级同步冻结（「一下快一下慢」根源之一）；现场形变的同步兜底不变
- **形变贴图自适应 dpr**（v1.4.0）：过渡态关键帧面积 >16000px² 时贴图 dpr 2→1.5（生成成本 −44%，300ms 过渡态视觉无差；落定态 autoResize 全质量重同步）；液桥组贴图 >140000px² 再降 0.75
- **solidShapes 'auto' 单行/多行分族**（v1.3.0）：`[sel, r, 'auto']` 矮（≤56px 单行）→ G2 超平滑胶囊、高（多行）→ 超椭圆 r，每次重裁按当前高度动态重判

## 安装

```bash
# npm（发布后）
npm install liquid-glass-engine

# 或从 tarball 安装（离线/私有源）
npm install ./liquid-glass-engine-1.4.0.tgz

# bun / pnpm workspace 同理
bun add liquid-glass-engine
```

Peer 依赖：`react >= 18`。无其他运行时依赖。

## 快速上手

三步接入（以 Next.js App Router 为例）：

```tsx
// app/page.tsx
import LiquidGlassEngine from 'liquid-glass-engine';
import 'liquid-glass-engine/styles.css';

const config = {
  glasses: [
    // 形状族：circle | capsule | squircle | roundrect
    // 档位：pro | flash | auto（缺省 auto）
    { sel: '.my-btn',   kind: 'circle',   draggable: true,  maxPull: 14.4, tier: 'auto' },
    { sel: '.my-card',  kind: 'squircle', rNom: 16, draggable: false, tier: 'pro' },
    { sel: '.my-input', kind: 'roundrect', rNom: 24, draggable: true, maxPull: 10, tier: 'pro' },
  ],
  // 自动变色的环境采样源（按优先级取第一个命中者）
  bgImageSel: ['.background img'],
};

export default function Page() {
  return (
    <>
      <LiquidGlassEngine {...config} />
      <div className="my-btn">按钮内容（玻璃本体样式由你的 CSS 决定）</div>
      <div className="my-card">卡片内容</div>
    </>
  );
}
```

引擎渲染 `null`，全部机制命令式驱动：扫描选择器命中的元素 → 注入 SVG 滤镜（折射/模糊/阴影）+ 高光层 + 辉光层 → rAF 帧循环逐帧维护。**玻璃本体的背景色/边框/圆角由宿主 CSS 承担**，引擎负责光学材质（折射、高光、阴影、辉光、自适应颜色）。

> 客户端组件：包入口带 `'use client'`，可直接在服务端组件中引用；配置必须是可序列化纯数据（通过 RSC 边界传递）。
> 配置在挂载时读取一次；运行期更换配置请以 `key` 重挂载。

## 配置参考（LiquidGlassConfig）

| 字段 | 类型 | 缺省 | 说明 |
|------|------|------|------|
| `glasses` | `GlassDef[]` | `[]` | 玻璃定义清单（选择器 → 形状/档位/颜色模式）。**v1.3.0**：全部玻璃本体被 ResizeObserver 观察（autoResize），内容驱动的尺寸变化（输入框行高增长）即时重同步几何 |
| `solidPress` | `string[]` | `[]` | 实体按压目标（白色实体钮：统一按压等比律 + 子层辉光，非玻璃） |
| `solidShapes` | `SolidShapeDef[]` | `[]` | 实体图形 G2 超平滑化 `[sel, r, kind]`（r=999 → 全胶囊）；**v1.3.0** `kind:'auto'`：矮（≤56px 单行）→ G2 胶囊、高（多行）→ 超椭圆 r（聊天气泡单行胶囊/多行圆角矩形）；动态节点 MutationObserver 去抖 150ms 重扫 |
| `fgSel` | `string` | `'svg'` | 玻璃内前景选择器（图标/文字只允许黑/白，与玻璃颜色相反） |
| `textProbeSel` | `string` | `''` | 玻璃下方内容文本探针（自动模糊的文字密度源）；空串关闭增益 |
| `bgImageSel` | `string[]` | `[]` | 环境亮度采样源（自动变色），按优先级取第一个命中的 `img` |
| `whiteScreenMatch` | `{attr,value}` | — | `body[data-attr="value"]` 命中 → 亮度环境切换为纯白参考（浅色屏幕） |
| `overlaySel` | `string` | — | 覆盖层优先判定：命中时白底判定让位（如全屏播放界面打开） |

## GlassDef 参考

| 字段 | 类型 | 说明 |
|------|------|------|
| `sel` | `string` | CSS 选择器（可命中多个元素） |
| `kind` | `'circle' \| 'capsule' \| 'squircle' \| 'roundrect'` | 形状族（roundrect = iOS 连续曲率圆角矩形） |
| `rNom` | `number` | squircle 名义圆角 |
| `shadow` | `{y,sigma,a} \| null` | 掩膜阴影层参数；统一从 `$m.outerShadow` 派生（`GLASS_SHADOW`），禁止手写数值 |
| `draggable` | `boolean` | 是否参与果冻拖拽（跟随系数 12%） |
| `maxPull` | `number` | **v1.1.0** 果冻拖拽位移上限（px），缺省 `48`。拖动范围规范：48×48 圆钮 `0.3×直径 ≈ 14.4`（果冻感但不离位）；胶囊/方钮、长条控件、输入面板 `≤ 10`。**v1.2.0**：超限后不再硬钳 —— 以初始 5%、随指针位移线性衰减到 0 的速度继续缓移（240 指针 px 内最多再挪 ~6px），表达"到达边界范围" |
| `shadowZ` | `number` | **v1.2.0** 掩膜阴影层 z-index（缺省不设）。阴影层挂在玻璃父级、紧邻玻璃之前，被正 z 兄弟元素遮挡时按需指定：`-1` = 父背景之上、全部兄弟之下；`> 障碍 z` = 越过障碍 |
| `fgSel` | `string` | 该玻璃额外前景选择器（并入黑白令牌） |
| `color` | 见下 | 颜色模式，缺省 `auto` |
| `tier` | `'pro' \| 'flash' \| 'auto'` | 渲染档位，缺省 `'auto'` |
| `bridgeLarge` | `boolean` | **v1.3.0** 大件液桥资格（输入面板等多行生长控件旁路 min-dim 100 / 面积 3e4 上限，长边仍 ≤720）。缺省 `false`。配对间距窗口 (12,24] 与重叠排除不变 |

**颜色模式**：

```ts
color?: { mode: 'auto' }                 // 自动变色：环境采样 + 三色调 + 眼适应
     | { mode: 'unified'; whiteT: number; alpha: number;
         expandedAlpha?: { attr: string; value: string; alpha: number } };
// unified = 统一颜色（固定白度/透明度，不随背景变化）
// expandedAlpha：body[data-attr="value"] 时 alpha 提升至 max(alpha, expandedAlpha.alpha)
//              （如上传面板展开 → 材质趋实 0.92）
```

## 事件编排（lgEvents）

界面转场（形变/飞行/分裂/合并）不通过 props，而是通过 window 事件总线驱动——引擎与 UI 框架完全解耦：

```ts
import { lgEvents } from 'liquid-glass-engine';

lgEvents.morph({ sel: '.my-btn', kind: 'capsule', w: 220 });            // 形变（弹簧 + 逐帧连续轮廓，缺省软弹簧 ≈400ms）
lgEvents.morph({ sel: '.my-btn', kind: 'squircle', w: 200, h: 112, r: 24, dur: 300 }); // dur(ms) 时间驱动形变；节奏统一令牌见 docs/06 §1.24
lgEvents.setGeometry({ sel: '.my-btn', kind: 'circle', w: 48, h: 48 }); // 即时几何（v1.2.0，构造"变形起点"）
lgEvents.emerge('.new-btn', '.my-card');  // 分裂出生：新钮从卡片弹开（代替飞入）
lgEvents.merge('.old-btn', '.my-card');   // 合并吸收：旧钮滑回卡片消失（代替飞出）
lgEvents.refresh();                        // 动态 DOM 挂载/卸载后增量注册
lgEvents.bgChange();                       // 背景图变化后重建环境亮度图
lgEvents.precache({ sel: '.my-btn', kind: 'circle' }); // 空闲预计算（首次形变零阻塞）
```

| 事件 | 载荷 | 行为 |
|------|------|------|
| `lg-morph-glass` | `{sel, kind, w?, h?, r?, dur?, styleLerp?}` | 三族权重混合场形变（弹簧积分 + 逐帧点阵混合连续轮廓）；**v1.3.0** `dur` ms → 时间驱动 liquidSettle，settle 严格 ≈ dur |
| `lg-fly-glass` | `{sel, mode:'out'\|'back'\|'to', x?, y?, dur?}` | 推入曲线飞行 cubic-bezier(0.32,0.72,0,1)·350ms |
| `lg-park-glass` | `{sel, x, y}` | 立即停靠（新挂载玻璃预置屏幕外） |
| `lg-split-glass` | `{sel}` | 玻璃分裂（重叠双生 → 白颈 → 弹簧分离） |
| `lg-emerge-glass` | `{sel, from}` | 分裂出生（代替飞入） |
| `lg-merge-glass` | `{sel, into}` | 合并吸收（代替飞出） |
| `lg-morph-precache` | `{sel, ...morph}` | 空闲预计算形变关键帧 |
| `lg-refresh-glass` | — | 增量注册新玻璃 / 清理已断开实例 |
| `lg-bg-change` | — | 重建环境亮度采样图 |

## CSS 钩子

| 类名/属性 | 作用 |
|-----------|------|
| `.lg-no-press` | 禁用该玻璃的按压/辉光（如输入框角色） |
| `.lg-no-drag` | 禁用该玻璃的果冻拖拽 |
| `.lg-no-bridge`（祖先类） | 该子树内玻璃不参与液桥分组 |
| `data-lg-no-bridge-when="attr:value"` | `body[data-attr="value"]` 时该玻璃不参与液桥（如上传面板展开） |
| `.lg-ui` | 引擎注入层标记（阴影/辉光层），宿主无需使用 |

## Flash / Pro 档位

| tier | 行为 | 适用 |
|------|------|------|
| `'pro'` | 全速渲染（60fps 逐帧更新） | 转场主角、高透明大面玻璃 |
| `'flash'` | 降耗档：采样降频（10Hz→2Hz）+ 运动更新 30fps + 静止停帧（零 DOM 写入），视觉基本不变 | 不重要的常驻静止小钮 |
| `'auto'`（缺省） | 按活动性自动升降：转场/拖拽/融合/形变中 → Pro；静止小控件 → Flash | 大多数控件 |

## 设计约定（铁律）

1. **阴影唯一来源**：所有玻璃阴影必须从 `$m.outerShadow` 派生（`GLASS_SHADOW`），全站禁止手写阴影数值
2. **高光骑在边界上**：高光与几何 SDF 同源，永远贴合玻璃轮廓
3. **液桥只属于邻近同组胶囊**：成员短边 ≤100px、squircle 面积 ≤30000px²，卡片自动排除；原位即成桥的对被禁止
4. **转场逐帧连续**：弹簧积分驱动（k=0.18, ζ=0.62；形状路径软弹簧 k=0.072），禁止贝塞尔离散档位
5. **图标切换禁用 `filter: blur()` / `backdrop-filter`**：只用 opacity 交叉淡化、clip-path、mask、scale
6. **玻璃本体样式归宿主**：引擎只负责光学材质层

## 文档

| 文档 | 内容 |
|------|------|
| [docs/01-设计规范与注意事项.md](./docs/01-设计规范与注意事项.md) | 原始设计规范（玻璃层级/材质/暗黑细则） |
| [docs/02-动效.md](./docs/02-动效.md) | 动效体系总纲（就近转换/材料交接） |
| [docs/03-动效体系补充.md](./docs/03-动效体系补充.md) | 动效细则补充（弹簧/液桥参数） |
| [docs/04-圆角规范与同心对齐.md](./docs/04-圆角规范与同心对齐.md) | 圆角与同心对齐规范 |
| [docs/05-设计补充问题.md](./docs/05-设计补充问题.md) | 设计裁决记录（颜色/白底玻璃等） |
| [docs/06-应用侧规范汇编.md](./docs/06-应用侧规范汇编.md) | **唯一权威汇编**：应用侧实操要求（2026-10-24 八条修正：圆角一致性/阴影清理/弹窗主动关闭/就近配额/拖动范围 maxPull）+ 01~05 核心条款，冲突以本汇编为准 |
| [docs/HOW-TO-APPLY.md](./docs/HOW-TO-APPLY.md) | 实战应用指南：如何在自己的项目里用好液态玻璃 |
| [examples/](./examples/) | 最小接入示例 |

## 框架集成说明

- **Next.js App Router**：包入口自带 `'use client'`，可直接在服务端组件引用并传纯数据配置；样式在任意服务端组件 `import 'liquid-glass-engine/styles.css'`
- **Vite / CRA / Rspack**：同上，无特殊配置
- **引擎只能挂载一个实例**（每页一次）；多个实例请分区选择器并自行隔离
- 引擎监听 `window` 尺寸变化与 DOM 变更（MutationObserver 去抖重扫实体图形），动态挂载的玻璃请派发 `lgEvents.refresh()`

## License

MIT
