# 示例

## basic-usage.tsx

最小接入示例：圆形玻璃钮（点击形变为胶囊）+ 高透明玻璃卡片 + 实体 G2 胶囊 + 自动变色环境采样。

运行方式（任选其一）：

1. **复制到现有项目**：把 `basic-usage.tsx` 拷入任意 React 18+ 项目（Next.js App Router / Vite / CRA 均可），安装本包后渲染 `<Demo />`
2. **在本仓库内**：示例已由 `packages/liquid-glass/examples/basic-usage.tsx` 提供，根应用（src/app/page.tsx）是完整的实战参考——玻璃 13 块、实体图形 12 类、全部转场编排

## 完整实战参考

根仓库的 Apple Music 复刻应用即本引擎的"官方 demo"：

- `src/lib/musicGlassConfig.ts` —— 玻璃清单/实体图形/采样源的完整配置范例（含 tier 分档策略）
- `src/components/messages/MessagesProvider.tsx` —— lgEvents 编排范例（morph/emerge/merge/park/precache 全套）
- `src/components/player/CrossfadeImg.tsx` —— `lgEvents.bgChange()` 背景切换范例
