'use client';

/**
 * liquid-glass-engine 最小接入示例
 * ----------------------------------------------------------
 * 一块会流动的玻璃按钮 + 一块高透明玻璃卡片 + 一次形变转场。
 * 复制到任意 Next.js / Vite React 项目即可运行。
 */

import { useEffect } from 'react';
import LiquidGlassEngine, { lgEvents } from 'liquid-glass-engine';
import 'liquid-glass-engine/styles.css';

/** 玻璃本体样式（背景色/边框/圆角）由宿主 CSS 承担 —— 这里用内联
 *  style 演示；真实项目请写在你的样式表里。 */
const glassBase: React.CSSProperties = {
  position: 'relative',
  background: 'rgba(255,255,255,0.10)',
  border: '0.5px solid rgba(255,255,255,0.25)',
  color: '#fff',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  cursor: 'pointer',
};

export default function Demo() {
  /* 挂载后空闲预计算形变关键帧 —— 首次形变零阻塞 */
  useEffect(() => {
    const idle = (window as unknown as { requestIdleCallback?: (cb: () => void) => number })
      .requestIdleCallback;
    (idle ?? ((cb: () => void) => window.setTimeout(cb, 200)))(() => {
      lgEvents.precache({ sel: '.demo-btn', kind: 'capsule', w: 200 });
    });
  }, []);

  return (
    <>
      {/* 引擎挂载点（一页一个实例；渲染 null） */}
      <LiquidGlassEngine
        glasses={[
          /* 圆形玻璃钮：auto 档（静止停帧，交互自动升 Pro） */
          { sel: '.demo-btn', kind: 'circle', draggable: true, tier: 'auto' },
          /* 高透明大面卡片：Pro 档（转场主角） */
          { sel: '.demo-card', kind: 'squircle', rNom: 16, tier: 'pro' },
        ]}
        /* 实体图形超平滑化（非玻璃，但形状同样连续曲率） */
        solidShapes={[['.demo-pill', 999, 'capsule']]}
        /* 自动变色：环境采样源 */
        bgImageSel={['.demo-bg img']}
      />

      {/* 深色背景（自动变色会输出白色调玻璃） */}
      <div className="demo-bg" style={{ position: 'fixed', inset: 0, background: '#1c1c1e' }}>
        <img src="/bg.jpg" alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
      </div>

      <div style={{ position: 'relative', padding: 80, display: 'grid', gap: 40, justifyItems: 'start' }}>
        {/* 玻璃按钮：点击在 64 圆 ⇄ 200×52 胶囊 之间形变 */}
        <div
          className="demo-btn"
          style={{ ...glassBase, width: 64, height: 64, borderRadius: 999 }}
          onClick={() => {
            lgEvents.morph({
              sel: '.demo-btn',
              kind: 'capsule',
              w: 200, h: 52,
              styleLerp: [{ prop: 'borderRadius', to: 26 }],
            });
          }}
        >
          <svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor">
            <path d="M12 2l2.4 7.2H22l-6 4.4 2.3 7.2-6.3-4.5-6.3 4.5L8 13.6l-6-4.4h7.6z" />
          </svg>
        </div>

        {/* 玻璃卡片 */}
        <div className="demo-card" style={{ ...glassBase, width: 340, height: 120, borderRadius: 16 }}>
          <span style={{ fontSize: 15 }}>高透明玻璃卡片（tier: pro）</span>
        </div>

        {/* 实体胶囊（G2 超平滑，非玻璃） */}
        <div
          className="demo-pill"
          style={{ ...glassBase, padding: '10px 24px', borderRadius: 999, background: 'rgba(255,255,255,0.16)' }}
        >
          实体 G2 胶囊（solidShapes）
        </div>
      </div>
    </>
  );
}
